# VAPT Report Management Platform - Design Guidelines

## Design Approach

**Selected Approach:** Design System - Carbon Design + Material Design Hybrid
**Justification:** Enterprise cybersecurity platform requiring data-dense displays, professional trust signals, and complex workflow visualization. Carbon Design excels at enterprise data applications, while Material Design provides robust component patterns for forms and interactions.

**Core Principles:**
- Trust & Security: Professional, confidence-inspiring interface
- Data Clarity: Complex information presented with clear hierarchy
- Workflow Visibility: Status, progress, and next actions always clear
- Role Differentiation: Each role sees relevant, focused information

---

## Color Palette

### Dark Mode Primary (Default)
- **Background Base:** 220 15% 8% (deep navy-slate)
- **Background Elevated:** 220 12% 12% (cards, panels)
- **Background Interactive:** 220 10% 16% (hover states)
- **Primary Brand:** 210 90% 55% (trust blue - CTAs, active states)
- **Primary Hover:** 210 85% 48%
- **Success:** 145 65% 45% (verified, approved status)
- **Warning:** 38 92% 58% (pending review, needs attention)
- **Error/Critical:** 358 75% 58% (critical vulnerabilities, failures)
- **Info:** 200 85% 52% (informational alerts)
- **Text Primary:** 220 15% 95%
- **Text Secondary:** 220 10% 70%
- **Text Muted:** 220 8% 50%
- **Border Subtle:** 220 12% 20%
- **Border Strong:** 220 10% 28%

### Light Mode
- **Background Base:** 220 20% 98%
- **Background Elevated:** 0 0% 100%
- **Primary Brand:** 210 95% 48%
- **Text Primary:** 220 15% 15%
- **Text Secondary:** 220 10% 35%
- **Border:** 220 12% 88%

### Severity Color System (Vulnerability Ratings)
- **Critical:** 358 75% 58% with 358 75% 20% background
- **High:** 15 85% 55% with 15 85% 22% background
- **Medium:** 38 92% 58% with 38 92% 25% background
- **Low:** 200 70% 50% with 200 70% 25% background
- **Info:** 145 55% 48% with 145 55% 25% background

---

## Typography

**Font Families:**
- **Primary (UI):** Inter (Google Fonts) - Clean, professional, excellent readability
- **Monospace (Code/Technical):** JetBrains Mono (Google Fonts) - For POC code, payloads, technical details
- **Display (Optional Headers):** Inter with tighter tracking

**Type Scale:**
- **Hero/Dashboard Title:** text-4xl (36px) font-bold tracking-tight
- **Section Headers:** text-2xl (24px) font-semibold
- **Card Titles:** text-lg (18px) font-semibold
- **Body Text:** text-base (16px) font-normal
- **Secondary/Meta:** text-sm (14px) font-normal
- **Captions/Labels:** text-xs (12px) font-medium uppercase tracking-wide
- **Technical/Code:** text-sm (14px) font-mono

---

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16, 20, 24
- **Component Padding:** p-4 to p-6 for cards
- **Section Spacing:** py-12 to py-16 for major sections
- **Element Gaps:** gap-4 to gap-8 for grids/flexbox
- **Form Element Spacing:** space-y-4 for form fields

**Grid System:**
- **Dashboard Layouts:** 12-column grid with sidebar
- **Sidebar Width:** 64 (256px) or 80 (320px) fixed
- **Main Content:** max-w-7xl centered with px-6 to px-8
- **Card Grids:** grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6

---

## Component Library

### Navigation
- **Top Bar:** Fixed header (h-16) with role indicator, notification bell, user avatar, dark/light toggle
- **Sidebar:** Fixed left navigation with collapsible sections, active state indicators, role-based menu items
- **Breadcrumbs:** For deep navigation (Projects > Project Name > Findings)

### Dashboards (Role-Specific)
- **Stat Cards:** 3-4 column grid showing key metrics (Total Projects, Pending Reviews, Critical Findings) with icons, large numbers, trend indicators
- **Activity Timeline:** Vertical timeline with icons, timestamps, user avatars showing recent actions
- **Charts:** Severity distribution (donut), project status (bar), monthly trends (line)
- **Quick Actions:** Prominent CTAs for role-specific tasks (Create Project, Submit Report)

### Data Tables
- **Project List:** Sortable columns, status badges, action menu per row, search/filter toolbar
- **Vulnerability Table:** Severity badges, expand/collapse for details, bulk selection
- **Striped Rows:** Alternating background for readability
- **Sticky Headers:** Column headers remain visible on scroll

### Forms
- **Input Fields:** Rounded borders, focus ring in primary color, floating labels or top labels
- **Select Dropdowns:** Custom styled with chevron icon, searchable for long lists
- **File Upload:** Drag-and-drop zones with upload progress, file type icons, preview thumbnails
- **Rich Text Editor:** For POC descriptions, remediation steps (toolbar with formatting options)
- **Multi-Step Forms:** Progress indicator, back/next navigation, section validation

### Cards & Panels
- **Project Cards:** Elevated shadow, client name, assessment type badge, assigned team avatars, status indicator, progress bar
- **Vulnerability Cards:** Severity badge (left border accent), title, CVSS score, affected asset, quick actions
- **Report Preview Cards:** Thumbnail, version number, approval status, download button
- **Info Panels:** Bordered containers for metadata (Created Date, Assigned To, Deadline)

### Status & Badges
- **Status Pills:** Rounded-full badges with status colors (Draft, In Review, Approved, Fixed, Revalidation Needed)
- **Severity Badges:** Larger badges with bold text for vulnerability severity
- **Role Tags:** Small badges indicating user roles
- **Count Badges:** Notification counts on icons (absolute positioned)

### Modals & Overlays
- **Confirmation Dialogs:** Centered overlay for destructive actions
- **Detail Modals:** Slide-in panels from right for viewing full details
- **Image Lightbox:** Full-screen overlay for POC screenshots with zoom
- **Loading Overlays:** Spinner with backdrop blur during async operations

### Chat Interface
- **Message Bubbles:** Differentiated sender/receiver with timestamps
- **Thread View:** Indented replies, collapse/expand threads
- **File Attachments:** Preview thumbnails in messages, download links
- **Typing Indicators:** Animated dots when others are typing
- **Channel Sidebar:** Project threads, direct messages, unread counts

### Reports
- **Report Builder:** Multi-section layout with drag-drop ordering, live preview
- **Executive Summary:** Large text blocks with charts/graphs
- **Findings Section:** Table format with severity, title, description, POC toggle
- **Export Preview:** PDF-style layout preview before generation

### Notifications
- **Toast Notifications:** Top-right corner, auto-dismiss, icon + message + action button
- **Notification Center:** Dropdown from bell icon, grouped by type, mark as read
- **Email Templates:** Consistent branding, clear CTAs, relevant project context

---

## Animations

**Minimal & Purposeful:**
- **Micro-interactions:** Button hover states (subtle scale/shadow), focus rings
- **Transitions:** Smooth modal open/close (300ms ease), tab switching (200ms)
- **Loading States:** Skeleton screens for tables, spinner for async actions
- **No:** Elaborate scroll animations, distracting effects

---

## Images

**Usage:**
- **Dashboard Header:** Optional abstract geometric pattern or cybersecurity-themed subtle background (lock icons, circuit patterns) as decorative element, not hero image
- **Empty States:** Illustrations for "No projects yet", "No vulnerabilities found"
- **User Avatars:** Profile pictures, fallback to initials with color-coded backgrounds
- **POC Screenshots:** Analyst-uploaded evidence displayed in cards/modals with zoom capability
- **Icons:** Use Heroicons throughout for consistency (shield, lock, document, chart, user, etc.)

**Hero Image:** No traditional hero section - this is a utility dashboard application, not a marketing site

---

## Page-Specific Layouts

### Login Page
- Centered card on gradient background, logo, MFA options, "Remember me" checkbox

### Admin Dashboard
- Sidebar + top bar, 4-column stat cards, project table, activity feed, team performance chart

### Analyst Workspace
- Assigned projects list, active findings editor (split view: form + preview), quick-add vulnerability from DB

### Client Portal
- Clean white-label design, project overview, findings table with fix status controls, upload evidence section

### Report Review
- Side-by-side layout: report preview (left 60%) + comment thread (right 40%), approval toolbar

### Chat Interface
- Full-height layout: channel list (left 20%) + message thread (center 60%) + member list (right 20%)

---

**Key Differentiator:** This design balances enterprise professionalism with modern usability, ensuring security teams can work efficiently while clients experience a trustworthy, transparent platform.