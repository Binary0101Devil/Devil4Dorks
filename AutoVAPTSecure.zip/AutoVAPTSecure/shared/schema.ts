import { sql } from 'drizzle-orm';
import { relations } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  pgEnum,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Enums
export const roleEnum = pgEnum("role", ["superadmin", "admin", "marketing", "analyst", "reviewer", "client"]);
export const projectStatusEnum = pgEnum("project_status", ["draft", "assigned", "in_progress", "under_review", "approved", "sent_to_client", "revalidation", "completed"]);
export const assessmentTypeEnum = pgEnum("assessment_type", ["web", "api", "mobile", "cloud", "infrastructure", "config_review"]);
export const severityEnum = pgEnum("severity", ["critical", "high", "medium", "low", "info"]);
export const findingStatusEnum = pgEnum("finding_status", ["open", "acknowledged", "fixed", "revalidation_needed", "verified_fixed", "not_fixed"]);
export const notificationTypeEnum = pgEnum("notification_type", ["project_assigned", "review_requested", "review_completed", "client_notification", "revalidation_requested", "general"]);

// Users table (required for Replit Auth + role extension)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: roleEnum("role").notNull().default("client"),
  organization: varchar("organization"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// Projects table
export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  clientId: varchar("client_id").notNull().references(() => users.id),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  assessmentType: assessmentTypeEnum("assessment_type").notNull(),
  status: projectStatusEnum("status").notNull().default("draft"),
  scopeDocuments: text("scope_documents").array(),
  assignedAnalystId: varchar("assigned_analyst_id").references(() => users.id),
  assignedReviewerId: varchar("assigned_reviewer_id").references(() => users.id),
  createdById: varchar("created_by_id").notNull().references(() => users.id),
  deadline: timestamp("deadline"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

// Vulnerability database (preloaded templates)
export const vulnerabilities = pgTable("vulnerabilities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description").notNull(),
  impact: text("impact").notNull(),
  remediation: text("remediation").notNull(),
  severity: severityEnum("severity").notNull(),
  cvssScore: varchar("cvss_score", { length: 10 }),
  cweId: varchar("cwe_id", { length: 50 }),
  category: varchar("category", { length: 100 }),
  isTemplate: boolean("is_template").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertVulnerabilitySchema = createInsertSchema(vulnerabilities).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertVulnerability = z.infer<typeof insertVulnerabilitySchema>;
export type Vulnerability = typeof vulnerabilities.$inferSelect;

// Findings (project-specific vulnerabilities with POC)
export const findings = pgTable("findings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
  vulnerabilityId: varchar("vulnerability_id").references(() => vulnerabilities.id),
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description").notNull(),
  impact: text("impact").notNull(),
  remediation: text("remediation").notNull(),
  severity: severityEnum("severity").notNull(),
  cvssScore: varchar("cvss_score", { length: 10 }),
  cweId: varchar("cwe_id", { length: 50 }),
  affectedAsset: varchar("affected_asset", { length: 500 }),
  poc: text("poc"),
  stepsToReproduce: text("steps_to_reproduce"),
  evidenceFiles: text("evidence_files").array(),
  status: findingStatusEnum("status").notNull().default("open"),
  fixEvidence: text("fix_evidence").array(),
  revalidationNotes: text("revalidation_notes"),
  createdById: varchar("created_by_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertFindingSchema = createInsertSchema(findings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertFinding = z.infer<typeof insertFindingSchema>;
export type Finding = typeof findings.$inferSelect;

// Review comments
export const comments = pgTable("comments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  findingId: varchar("finding_id").references(() => findings.id, { onDelete: "cascade" }),
  projectId: varchar("project_id").references(() => projects.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  isResolved: boolean("is_resolved").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertCommentSchema = createInsertSchema(comments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertComment = z.infer<typeof insertCommentSchema>;
export type Comment = typeof comments.$inferSelect;

// Chat messages
export const chatMessages = pgTable("chat_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id, { onDelete: "cascade" }),
  senderId: varchar("sender_id").notNull().references(() => users.id),
  recipientId: varchar("recipient_id").references(() => users.id),
  content: text("content").notNull(),
  attachments: text("attachments").array(),
  isProjectChat: boolean("is_project_chat").notNull().default(true),
  readBy: text("read_by").array().notNull().default(sql`ARRAY[]::text[]`),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true,
});

export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;

// Notifications
export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  type: notificationTypeEnum("type").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  link: varchar("link", { length: 500 }),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;

// Audit logs
export const auditLogs = pgTable("audit_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  action: varchar("action", { length: 100 }).notNull(),
  entityType: varchar("entity_type", { length: 50 }).notNull(),
  entityId: varchar("entity_id", { length: 255 }),
  details: jsonb("details"),
  ipAddress: varchar("ip_address", { length: 50 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type AuditLog = typeof auditLogs.$inferSelect;

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  createdProjects: many(projects, { relationName: "createdBy" }),
  clientProjects: many(projects, { relationName: "client" }),
  assignedAsAnalyst: many(projects, { relationName: "analyst" }),
  assignedAsReviewer: many(projects, { relationName: "reviewer" }),
  findings: many(findings),
  comments: many(comments),
  sentMessages: many(chatMessages, { relationName: "sender" }),
  receivedMessages: many(chatMessages, { relationName: "recipient" }),
  notifications: many(notifications),
  auditLogs: many(auditLogs),
}));

export const projectsRelations = relations(projects, ({ one, many }) => ({
  client: one(users, { fields: [projects.clientId], references: [users.id], relationName: "client" }),
  createdBy: one(users, { fields: [projects.createdById], references: [users.id], relationName: "createdBy" }),
  assignedAnalyst: one(users, { fields: [projects.assignedAnalystId], references: [users.id], relationName: "analyst" }),
  assignedReviewer: one(users, { fields: [projects.assignedReviewerId], references: [users.id], relationName: "reviewer" }),
  findings: many(findings),
  comments: many(comments),
  chatMessages: many(chatMessages),
}));

export const vulnerabilitiesRelations = relations(vulnerabilities, ({ many }) => ({
  findings: many(findings),
}));

export const findingsRelations = relations(findings, ({ one, many }) => ({
  project: one(projects, { fields: [findings.projectId], references: [projects.id] }),
  vulnerability: one(vulnerabilities, { fields: [findings.vulnerabilityId], references: [vulnerabilities.id] }),
  createdBy: one(users, { fields: [findings.createdById], references: [users.id] }),
  comments: many(comments),
}));

export const commentsRelations = relations(comments, ({ one }) => ({
  finding: one(findings, { fields: [comments.findingId], references: [findings.id] }),
  project: one(projects, { fields: [comments.projectId], references: [projects.id] }),
  user: one(users, { fields: [comments.userId], references: [users.id] }),
}));

export const chatMessagesRelations = relations(chatMessages, ({ one }) => ({
  project: one(projects, { fields: [chatMessages.projectId], references: [projects.id] }),
  sender: one(users, { fields: [chatMessages.senderId], references: [users.id], relationName: "sender" }),
  recipient: one(users, { fields: [chatMessages.recipientId], references: [users.id], relationName: "recipient" }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, { fields: [notifications.userId], references: [users.id] }),
}));

export const auditLogsRelations = relations(auditLogs, ({ one }) => ({
  user: one(users, { fields: [auditLogs.userId], references: [users.id] }),
}));
