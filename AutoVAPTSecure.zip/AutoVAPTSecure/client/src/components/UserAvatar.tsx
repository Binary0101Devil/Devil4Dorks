import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface UserAvatarProps {
  firstName?: string | null;
  lastName?: string | null;
  profileImageUrl?: string | null;
  className?: string;
}

export function UserAvatar({
  firstName,
  lastName,
  profileImageUrl,
  className,
}: UserAvatarProps) {
  const initials = [firstName, lastName]
    .filter(Boolean)
    .map((name) => name?.[0])
    .join("")
    .toUpperCase();

  return (
    <Avatar className={className} data-testid="avatar-user">
      {profileImageUrl && (
        <AvatarImage
          src={profileImageUrl}
          alt={`${firstName || ""} ${lastName || ""}`}
          className="object-cover"
        />
      )}
      <AvatarFallback className="bg-primary/10 text-primary font-semibold">
        {initials || "U"}
      </AvatarFallback>
    </Avatar>
  );
}
