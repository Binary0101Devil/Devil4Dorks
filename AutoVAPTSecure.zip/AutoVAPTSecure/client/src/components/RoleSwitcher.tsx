import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Shield, ChevronDown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

type Role = "superadmin" | "admin" | "marketing" | "analyst" | "reviewer" | "client";

const roleLabels: Record<Role, string> = {
  superadmin: "Super Admin",
  admin: "Admin",
  marketing: "Marketing Team",
  analyst: "Analyst (Pen Tester)",
  reviewer: "Reviewer",
  client: "Client",
};

const roleDescriptions: Record<Role, string> = {
  superadmin: "Full system access",
  admin: "Manage users and projects",
  marketing: "Create and assign projects",
  analyst: "Perform security assessments",
  reviewer: "Review findings and reports",
  client: "View assigned projects",
};

export function RoleSwitcher() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const handleRoleSwitch = async (role: Role) => {
    try {
      setIsLoading(true);
      await apiRequest("POST", "/api/auth/switch-role", { role });

      await queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });

      toast({
        title: "Role Changed",
        description: `You are now logged in as ${roleLabels[role]}`,
      });

      window.location.reload();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to switch role",
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) return null;

  const currentRole = user.role as Role;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          disabled={isLoading}
          className="gap-2"
          data-testid="button-role-switcher"
        >
          <Shield className="h-4 w-4" />
          <span className="hidden sm:inline">{roleLabels[currentRole]}</span>
          <ChevronDown className="h-4 w-4 opacity-50" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64">
        <DropdownMenuLabel>Switch Role (Testing)</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {(Object.keys(roleLabels) as Role[]).map((role) => (
          <DropdownMenuItem
            key={role}
            onClick={() => handleRoleSwitch(role)}
            disabled={role === currentRole || isLoading}
            className="flex flex-col items-start gap-1 cursor-pointer"
            data-testid={`menuitem-role-${role}`}
          >
            <div className="flex items-center gap-2 w-full">
              <span className="font-medium">{roleLabels[role]}</span>
              {role === currentRole && (
                <span className="ml-auto text-xs text-muted-foreground">Current</span>
              )}
            </div>
            <span className="text-xs text-muted-foreground">{roleDescriptions[role]}</span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
