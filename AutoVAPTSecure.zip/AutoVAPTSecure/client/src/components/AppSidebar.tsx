import { useAuth } from "@/hooks/useAuth";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { UserAvatar } from "@/components/UserAvatar";
import { RoleBadge } from "@/components/RoleBadge";
import {
  LayoutDashboard,
  FolderKanban,
  Database,
  Users,
  MessageSquare,
  Bell,
  FileText,
  Shield,
  LogOut,
} from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";

const roleMenuItems = {
  superadmin: [
    { title: "Dashboard", url: "/", icon: LayoutDashboard },
    { title: "Projects", url: "/projects", icon: FolderKanban },
    { title: "Users", url: "/users", icon: Users },
    { title: "Vulnerabilities", url: "/vulnerabilities", icon: Database },
    { title: "Messages", url: "/messages", icon: MessageSquare },
    { title: "Notifications", url: "/notifications", icon: Bell },
  ],
  admin: [
    { title: "Dashboard", url: "/", icon: LayoutDashboard },
    { title: "Projects", url: "/projects", icon: FolderKanban },
    { title: "Team", url: "/team", icon: Users },
    { title: "Messages", url: "/messages", icon: MessageSquare },
    { title: "Notifications", url: "/notifications", icon: Bell },
  ],
  marketing: [
    { title: "Dashboard", url: "/", icon: LayoutDashboard },
    { title: "Projects", url: "/projects", icon: FolderKanban },
    { title: "Messages", url: "/messages", icon: MessageSquare },
    { title: "Notifications", url: "/notifications", icon: Bell },
  ],
  analyst: [
    { title: "Dashboard", url: "/", icon: LayoutDashboard },
    { title: "My Projects", url: "/projects", icon: FolderKanban },
    { title: "Vulnerabilities", url: "/vulnerabilities", icon: Database },
    { title: "Messages", url: "/messages", icon: MessageSquare },
    { title: "Notifications", url: "/notifications", icon: Bell },
  ],
  reviewer: [
    { title: "Dashboard", url: "/", icon: LayoutDashboard },
    { title: "Reviews", url: "/projects", icon: FileText },
    { title: "Messages", url: "/messages", icon: MessageSquare },
    { title: "Notifications", url: "/notifications", icon: Bell },
  ],
  client: [
    { title: "Dashboard", url: "/", icon: LayoutDashboard },
    { title: "My Projects", url: "/projects", icon: FolderKanban },
    { title: "Messages", url: "/messages", icon: MessageSquare },
    { title: "Notifications", url: "/notifications", icon: Bell },
  ],
};

export function AppSidebar() {
  const { user } = useAuth();
  const [location] = useLocation();

  if (!user) return null;

  const menuItems = roleMenuItems[user.role] || roleMenuItems.client;

  return (
    <Sidebar>
      <SidebarHeader className="border-b border-sidebar-border p-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-md bg-sidebar-primary flex items-center justify-center flex-shrink-0">
            <Shield className="h-6 w-6 text-sidebar-primary-foreground" />
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-sm font-bold text-sidebar-foreground truncate">
              VAPT Platform
            </h2>
            <p className="text-xs text-muted-foreground truncate">
              Security Assessment
            </p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => {
                const isActive = location === item.url;
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      isActive={isActive}
                      data-testid={`nav-${item.title.toLowerCase().replace(/\s+/g, "-")}`}
                    >
                      <a href={item.url}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </a>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border p-4">
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <UserAvatar
              firstName={user.firstName}
              lastName={user.lastName}
              profileImageUrl={user.profileImageUrl}
              className="h-10 w-10"
            />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-sidebar-foreground truncate">
                {user.firstName} {user.lastName}
              </p>
              <p className="text-xs text-muted-foreground truncate">
                {user.email}
              </p>
            </div>
          </div>
          <RoleBadge role={user.role} />
          <Button
            variant="outline"
            size="sm"
            className="w-full"
            asChild
            data-testid="button-logout"
          >
            <a href="/api/logout">
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </a>
          </Button>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
