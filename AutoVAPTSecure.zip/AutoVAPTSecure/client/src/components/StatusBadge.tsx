import { Badge } from "@/components/ui/badge";
import {
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  FileCheck,
  Send,
  RefreshCw,
  FileText,
} from "lucide-react";

type ProjectStatus =
  | "draft"
  | "assigned"
  | "in_progress"
  | "under_review"
  | "approved"
  | "sent_to_client"
  | "revalidation"
  | "completed";

type FindingStatus =
  | "open"
  | "acknowledged"
  | "fixed"
  | "revalidation_needed"
  | "verified_fixed"
  | "not_fixed";

interface StatusBadgeProps {
  status: ProjectStatus | FindingStatus;
  className?: string;
}

const statusConfig: Record<
  ProjectStatus | FindingStatus,
  { label: string; icon: any; variant: any; className?: string }
> = {
  draft: {
    label: "Draft",
    icon: FileText,
    variant: "secondary",
  },
  assigned: {
    label: "Assigned",
    icon: Clock,
    variant: "outline",
    className: "border-chart-3 text-chart-3",
  },
  in_progress: {
    label: "In Progress",
    icon: RefreshCw,
    variant: "outline",
    className: "border-chart-1 text-chart-1",
  },
  under_review: {
    label: "Under Review",
    icon: AlertCircle,
    variant: "outline",
    className: "border-chart-3 text-chart-3",
  },
  approved: {
    label: "Approved",
    icon: CheckCircle2,
    variant: "outline",
    className: "border-chart-2 text-chart-2",
  },
  sent_to_client: {
    label: "Sent to Client",
    icon: Send,
    variant: "outline",
    className: "border-chart-1 text-chart-1",
  },
  revalidation: {
    label: "Revalidation",
    icon: RefreshCw,
    variant: "outline",
    className: "border-chart-3 text-chart-3",
  },
  completed: {
    label: "Completed",
    icon: FileCheck,
    variant: "outline",
    className: "border-chart-2 text-chart-2",
  },
  open: {
    label: "Open",
    icon: AlertCircle,
    variant: "destructive",
  },
  acknowledged: {
    label: "Acknowledged",
    icon: Clock,
    variant: "outline",
    className: "border-chart-3 text-chart-3",
  },
  fixed: {
    label: "Fixed",
    icon: CheckCircle2,
    variant: "outline",
    className: "border-chart-2 text-chart-2",
  },
  revalidation_needed: {
    label: "Revalidation Needed",
    icon: RefreshCw,
    variant: "outline",
    className: "border-chart-3 text-chart-3",
  },
  verified_fixed: {
    label: "Verified Fixed",
    icon: FileCheck,
    variant: "outline",
    className: "border-chart-2 text-chart-2",
  },
  not_fixed: {
    label: "Not Fixed",
    icon: XCircle,
    variant: "destructive",
  },
};

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = statusConfig[status];
  const Icon = config.icon;

  return (
    <Badge
      variant={config.variant}
      className={`gap-1 ${config.className || ""} ${className || ""}`}
      data-testid={`badge-status-${status}`}
    >
      <Icon className="h-3 w-3" />
      {config.label}
    </Badge>
  );
}
