import { Badge } from "@/components/ui/badge";
import { AlertCircle, AlertTriangle, Info, Shield, ShieldAlert } from "lucide-react";

type Severity = "critical" | "high" | "medium" | "low" | "info";

interface SeverityBadgeProps {
  severity: Severity;
  className?: string;
}

const severityConfig = {
  critical: {
    label: "Critical",
    icon: ShieldAlert,
    className: "bg-severity-critical-bg text-severity-critical border-severity-critical/30",
  },
  high: {
    label: "High",
    icon: AlertCircle,
    className: "bg-severity-high-bg text-severity-high border-severity-high/30",
  },
  medium: {
    label: "Medium",
    icon: AlertTriangle,
    className: "bg-severity-medium-bg text-severity-medium border-severity-medium/30",
  },
  low: {
    label: "Low",
    icon: Shield,
    className: "bg-severity-low-bg text-severity-low border-severity-low/30",
  },
  info: {
    label: "Info",
    icon: Info,
    className: "bg-severity-info-bg text-severity-info border-severity-info/30",
  },
};

export function SeverityBadge({ severity, className }: SeverityBadgeProps) {
  const config = severityConfig[severity];
  const Icon = config.icon;

  return (
    <Badge
      variant="outline"
      className={`${config.className} font-semibold gap-1 ${className || ""}`}
      data-testid={`badge-severity-${severity}`}
    >
      <Icon className="h-3 w-3" />
      {config.label}
    </Badge>
  );
}
