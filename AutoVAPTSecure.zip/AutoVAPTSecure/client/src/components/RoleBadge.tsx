import { Badge } from "@/components/ui/badge";
import {
  Shield,
  UserCog,
  Megaphone,
  Search,
  FileCheck,
  User,
} from "lucide-react";

type Role = "superadmin" | "admin" | "marketing" | "analyst" | "reviewer" | "client";

interface RoleBadgeProps {
  role: Role;
  className?: string;
}

const roleConfig: Record<Role, { label: string; icon: any; className: string }> = {
  superadmin: {
    label: "Superadmin",
    icon: Shield,
    className: "bg-primary/10 text-primary border-primary/30",
  },
  admin: {
    label: "Admin",
    icon: UserCog,
    className: "bg-chart-1/10 text-chart-1 border-chart-1/30",
  },
  marketing: {
    label: "Marketing",
    icon: Megaphone,
    className: "bg-chart-3/10 text-chart-3 border-chart-3/30",
  },
  analyst: {
    label: "Analyst",
    icon: Search,
    className: "bg-chart-2/10 text-chart-2 border-chart-2/30",
  },
  reviewer: {
    label: "Reviewer",
    icon: FileCheck,
    className: "bg-chart-5/10 text-chart-5 border-chart-5/30",
  },
  client: {
    label: "Client",
    icon: User,
    className: "bg-muted text-muted-foreground border-border",
  },
};

export function RoleBadge({ role, className }: RoleBadgeProps) {
  const config = roleConfig[role];
  const Icon = config.icon;

  return (
    <Badge
      variant="outline"
      className={`${config.className} gap-1 font-medium ${className || ""}`}
      data-testid={`badge-role-${role}`}
    >
      <Icon className="h-3 w-3" />
      {config.label}
    </Badge>
  );
}
