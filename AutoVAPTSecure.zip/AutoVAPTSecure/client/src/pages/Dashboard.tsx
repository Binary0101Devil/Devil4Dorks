import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  FolderKanban,
  AlertCircle,
  CheckCircle,
  Clock,
  TrendingUp,
  Users,
  FileText,
  Plus,
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Project } from "@shared/schema";
import { StatusBadge } from "@/components/StatusBadge";
import { Skeleton } from "@/components/ui/skeleton";
import { useLocation } from "wouter";

function DashboardStatCard({
  title,
  value,
  icon: Icon,
  trend,
  className,
}: {
  title: string;
  value: string | number;
  icon: any;
  trend?: string;
  className?: string;
}) {
  return (
    <Card className={className}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground font-medium">{title}</p>
            <p className="text-3xl font-bold text-foreground">{value}</p>
            {trend && (
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <TrendingUp className="h-3 w-3" />
                {trend}
              </p>
            )}
          </div>
          <div className="h-12 w-12 rounded-md bg-primary/10 flex items-center justify-center">
            <Icon className="h-6 w-6 text-primary" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Dashboard() {
  const { user, isLoading: authLoading } = useAuth();
  const [, setLocation] = useLocation();

  const { data: projects, isLoading: projectsLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    enabled: !!user,
  });

  if (authLoading) {
    return (
      <div className="p-6 space-y-6">
        <Skeleton className="h-12 w-64" />
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      </div>
    );
  }

  if (!user) return null;

  const getStatsForRole = () => {
    if (!projects) return { total: 0, active: 0, pending: 0, completed: 0 };

    const stats = {
      total: projects.length,
      active: projects.filter((p) =>
        ["in_progress", "under_review"].includes(p.status)
      ).length,
      pending: projects.filter((p) => ["draft", "assigned"].includes(p.status))
        .length,
      completed: projects.filter((p) => p.status === "completed").length,
    };

    return stats;
  };

  const stats = getStatsForRole();

  const getDashboardTitle = () => {
    switch (user.role) {
      case "superadmin":
      case "admin":
        return "Admin Dashboard";
      case "marketing":
        return "Marketing Dashboard";
      case "analyst":
        return "Analyst Workspace";
      case "reviewer":
        return "Reviewer Dashboard";
      case "client":
        return "Client Portal";
      default:
        return "Dashboard";
    }
  };

  const getQuickActions = () => {
    switch (user.role) {
      case "marketing":
        return [
          {
            label: "New Project",
            icon: Plus,
            action: () => setLocation("/projects/new"),
          },
        ];
      case "admin":
      case "superadmin":
        return [
          {
            label: "New Project",
            icon: Plus,
            action: () => setLocation("/projects/new"),
          },
          {
            label: "Manage Users",
            icon: Users,
            action: () => setLocation("/users"),
          },
        ];
      default:
        return [];
    }
  };

  const quickActions = getQuickActions();

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground tracking-tight">
            {getDashboardTitle()}
          </h1>
          <p className="text-muted-foreground mt-1">
            Welcome back, {user.firstName || user.email}
          </p>
        </div>
        {quickActions.length > 0 && (
          <div className="flex gap-2">
            {quickActions.map((action) => (
              <Button
                key={action.label}
                onClick={action.action}
                data-testid={`button-${action.label.toLowerCase().replace(/\s+/g, "-")}`}
              >
                <action.icon className="h-4 w-4 mr-2" />
                {action.label}
              </Button>
            ))}
          </div>
        )}
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        <DashboardStatCard
          title="Total Projects"
          value={projectsLoading ? "..." : stats.total}
          icon={FolderKanban}
          trend="+12% from last month"
          data-testid="stat-total-projects"
        />
        <DashboardStatCard
          title="Active"
          value={projectsLoading ? "..." : stats.active}
          icon={Clock}
          className="border-chart-1/30"
          data-testid="stat-active-projects"
        />
        <DashboardStatCard
          title="Pending Review"
          value={projectsLoading ? "..." : stats.pending}
          icon={AlertCircle}
          className="border-chart-3/30"
          data-testid="stat-pending-projects"
        />
        <DashboardStatCard
          title="Completed"
          value={projectsLoading ? "..." : stats.completed}
          icon={CheckCircle}
          className="border-chart-2/30"
          data-testid="stat-completed-projects"
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Recent Projects
            </CardTitle>
          </CardHeader>
          <CardContent>
            {projectsLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-16" />
                ))}
              </div>
            ) : projects && projects.length > 0 ? (
              <div className="space-y-3">
                {projects.slice(0, 5).map((project) => (
                  <div
                    key={project.id}
                    className="flex items-center justify-between p-4 border border-border rounded-md hover-elevate cursor-pointer"
                    onClick={() => setLocation(`/projects/${project.id}`)}
                    data-testid={`project-item-${project.id}`}
                  >
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-foreground truncate">
                        {project.name}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {project.assessmentType.toUpperCase()}
                      </p>
                    </div>
                    <StatusBadge status={project.status} />
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <FolderKanban className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No projects yet</p>
                {(user.role === "marketing" ||
                  user.role === "admin" ||
                  user.role === "superadmin") && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-4"
                    onClick={() => setLocation("/projects/new")}
                    data-testid="button-create-first-project"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Create First Project
                  </Button>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5" />
              Quick Stats
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-border">
                <span className="text-sm text-muted-foreground">
                  This Month
                </span>
                <span className="font-semibold text-foreground">
                  {stats.total}
                </span>
              </div>
              <div className="flex items-center justify-between pb-3 border-b border-border">
                <span className="text-sm text-muted-foreground">
                  In Progress
                </span>
                <span className="font-semibold text-chart-1">
                  {stats.active}
                </span>
              </div>
              <div className="flex items-center justify-between pb-3 border-b border-border">
                <span className="text-sm text-muted-foreground">
                  Awaiting Review
                </span>
                <span className="font-semibold text-chart-3">
                  {stats.pending}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Completed</span>
                <span className="font-semibold text-chart-2">
                  {stats.completed}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
