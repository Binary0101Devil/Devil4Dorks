import { useAuth } from "@/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageSquare, Send } from "lucide-react";
import { UserAvatar } from "@/components/UserAvatar";

export default function Messages() {
  const { user } = useAuth();

  if (!user) return null;

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-foreground tracking-tight">
          Messages
        </h1>
        <p className="text-muted-foreground mt-1">
          Communicate with your team in real-time
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6 h-[calc(100vh-16rem)]">
        <Card className="lg:col-span-1 overflow-hidden flex flex-col">
          <div className="p-4 border-b border-border">
            <h3 className="font-semibold text-foreground">Conversations</h3>
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            <div className="p-3 rounded-md hover-elevate cursor-pointer bg-accent/50">
              <div className="flex items-center gap-3">
                <UserAvatar
                  firstName="John"
                  lastName="Doe"
                  className="h-10 w-10"
                />
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm text-foreground truncate">
                    Project Team Chat
                  </p>
                  <p className="text-xs text-muted-foreground truncate">
                    Last message preview...
                  </p>
                </div>
              </div>
            </div>
          </div>
        </Card>

        <Card className="lg:col-span-2 overflow-hidden flex flex-col">
          <div className="p-4 border-b border-border">
            <div className="flex items-center gap-3">
              <UserAvatar firstName="Team" lastName="Chat" className="h-10 w-10" />
              <div>
                <h3 className="font-semibold text-foreground">Project Team Chat</h3>
                <p className="text-xs text-muted-foreground">4 members</p>
              </div>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-muted/20">
            <div className="flex items-start gap-3">
              <UserAvatar
                firstName="John"
                lastName="Doe"
                className="h-8 w-8 mt-1"
              />
              <div className="flex-1">
                <div className="flex items-baseline gap-2 mb-1">
                  <span className="font-medium text-sm text-foreground">
                    John Doe
                  </span>
                  <span className="text-xs text-muted-foreground">
                    10:30 AM
                  </span>
                </div>
                <div className="bg-card border border-border rounded-lg p-3 max-w-lg">
                  <p className="text-sm text-foreground">
                    Chat functionality will be available soon. Real-time messaging
                    for project collaboration.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="p-4 border-t border-border">
            <div className="flex gap-2">
              <Input
                placeholder="Type a message..."
                className="flex-1"
                data-testid="input-message"
              />
              <Button size="icon" data-testid="button-send-message">
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
