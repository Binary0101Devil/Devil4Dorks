import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Search, Filter, FolderKanban } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Project, User } from "@shared/schema";
import { StatusBadge } from "@/components/StatusBadge";
import { UserAvatar } from "@/components/UserAvatar";
import { Skeleton } from "@/components/ui/skeleton";
import { useLocation } from "wouter";
import { useState } from "react";
import { format } from "date-fns";

export default function Projects() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [assessmentFilter, setAssessmentFilter] = useState<string>("all");

  const { data: projects, isLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    enabled: !!user,
  });

  const { data: users } = useQuery<User[]>({
    queryKey: ["/api/users"],
    enabled: !!user && (user.role === "admin" || user.role === "superadmin"),
  });

  if (!user) return null;

  const canCreateProject =
    user.role === "marketing" ||
    user.role === "admin" ||
    user.role === "superadmin";

  const filteredProjects = projects?.filter((project) => {
    const matchesSearch =
      !searchQuery ||
      project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.description?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus =
      statusFilter === "all" || project.status === statusFilter;

    const matchesAssessment =
      assessmentFilter === "all" ||
      project.assessmentType === assessmentFilter;

    return matchesSearch && matchesStatus && matchesAssessment;
  });

  const getUserById = (id: string | null) => {
    if (!id || !users) return null;
    return users.find((u) => u.id === id);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground tracking-tight">
            Projects
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage your security assessment projects
          </p>
        </div>
        {canCreateProject && (
          <Button
            onClick={() => setLocation("/projects/new")}
            data-testid="button-new-project"
          >
            <Plus className="h-4 w-4 mr-2" />
            New Project
          </Button>
        )}
      </div>

      <Card>
        <CardHeader className="border-b border-border">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search projects..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search-projects"
              />
            </div>
            <div className="flex gap-2">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[180px]" data-testid="select-status-filter">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="assigned">Assigned</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="under_review">Under Review</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="sent_to_client">Sent to Client</SelectItem>
                  <SelectItem value="revalidation">Revalidation</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>

              <Select
                value={assessmentFilter}
                onValueChange={setAssessmentFilter}
              >
                <SelectTrigger className="w-[180px]" data-testid="select-assessment-filter">
                  <SelectValue placeholder="Assessment Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="web">Web Application</SelectItem>
                  <SelectItem value="api">API</SelectItem>
                  <SelectItem value="mobile">Mobile</SelectItem>
                  <SelectItem value="cloud">Cloud</SelectItem>
                  <SelectItem value="infrastructure">Infrastructure</SelectItem>
                  <SelectItem value="config_review">Config Review</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-24" />
              ))}
            </div>
          ) : filteredProjects && filteredProjects.length > 0 ? (
            <div className="divide-y divide-border">
              {filteredProjects.map((project) => {
                const analyst = getUserById(project.assignedAnalystId);
                const reviewer = getUserById(project.assignedReviewerId);

                return (
                  <div
                    key={project.id}
                    className="p-6 hover-elevate cursor-pointer"
                    onClick={() => setLocation(`/projects/${project.id}`)}
                    data-testid={`project-row-${project.id}`}
                  >
                    <div className="flex items-start gap-4">
                      <div className="flex-1 min-w-0 space-y-3">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 min-w-0">
                            <h3 className="font-semibold text-lg text-foreground truncate">
                              {project.name}
                            </h3>
                            {project.description && (
                              <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                                {project.description}
                              </p>
                            )}
                          </div>
                          <StatusBadge status={project.status} />
                        </div>

                        <div className="flex flex-wrap items-center gap-4 text-sm">
                          <div className="flex items-center gap-2">
                            <span className="text-muted-foreground">Type:</span>
                            <span className="font-medium text-foreground capitalize">
                              {project.assessmentType.replace(/_/g, " ")}
                            </span>
                          </div>

                          {project.deadline && (
                            <div className="flex items-center gap-2">
                              <span className="text-muted-foreground">
                                Deadline:
                              </span>
                              <span className="font-medium text-foreground">
                                {format(new Date(project.deadline), "MMM dd, yyyy")}
                              </span>
                            </div>
                          )}

                          <div className="flex items-center gap-2">
                            <span className="text-muted-foreground">Created:</span>
                            <span className="font-medium text-foreground">
                              {format(new Date(project.createdAt), "MMM dd, yyyy")}
                            </span>
                          </div>
                        </div>

                        {(analyst || reviewer) && (
                          <div className="flex items-center gap-4">
                            {analyst && (
                              <div className="flex items-center gap-2">
                                <span className="text-xs text-muted-foreground">
                                  Analyst:
                                </span>
                                <UserAvatar
                                  firstName={analyst.firstName}
                                  lastName={analyst.lastName}
                                  profileImageUrl={analyst.profileImageUrl}
                                  className="h-6 w-6"
                                />
                                <span className="text-sm font-medium text-foreground">
                                  {analyst.firstName} {analyst.lastName}
                                </span>
                              </div>
                            )}

                            {reviewer && (
                              <div className="flex items-center gap-2">
                                <span className="text-xs text-muted-foreground">
                                  Reviewer:
                                </span>
                                <UserAvatar
                                  firstName={reviewer.firstName}
                                  lastName={reviewer.lastName}
                                  profileImageUrl={reviewer.profileImageUrl}
                                  className="h-6 w-6"
                                />
                                <span className="text-sm font-medium text-foreground">
                                  {reviewer.firstName} {reviewer.lastName}
                                </span>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-12 text-center">
              <FolderKanban className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">
                No projects found
              </h3>
              <p className="text-muted-foreground mb-6">
                {searchQuery || statusFilter !== "all" || assessmentFilter !== "all"
                  ? "Try adjusting your filters"
                  : "Get started by creating your first project"}
              </p>
              {canCreateProject &&
                !searchQuery &&
                statusFilter === "all" &&
                assessmentFilter === "all" && (
                  <Button
                    onClick={() => setLocation("/projects/new")}
                    data-testid="button-create-first-project-empty"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Create First Project
                  </Button>
                )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
