import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Shield,
  FileSearch,
  Users,
  Clock,
  CheckCircle,
  BarChart3,
  Lock,
  FileCheck,
} from "lucide-react";
import { ThemeToggle } from "@/components/ThemeToggle";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-md bg-primary flex items-center justify-center">
              <Shield className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">VAPT Platform</h1>
              <p className="text-xs text-muted-foreground">
                Security Assessment Management
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button asChild data-testid="button-login">
              <a href="/api/login">Sign In</a>
            </Button>
          </div>
        </div>
      </header>

      <main>
        <section className="container mx-auto px-6 py-20 text-center">
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-4">
              <Shield className="h-4 w-4" />
              Enterprise Security Platform
            </div>
            <h2 className="text-5xl font-bold tracking-tight text-foreground">
              Streamline Your VAPT Workflow
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Comprehensive vulnerability assessment and penetration testing report
              management platform. From client onboarding to final report delivery
              and revalidation.
            </p>
            <div className="flex items-center justify-center gap-4 pt-4">
              <Button size="lg" asChild data-testid="button-get-started">
                <a href="/api/login">Get Started</a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="#features">Learn More</a>
              </Button>
            </div>
          </div>
        </section>

        <section id="features" className="container mx-auto px-6 py-16">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-foreground mb-3">
              Complete VAPT Lifecycle Management
            </h3>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Everything you need to manage security assessments from start to finish
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="hover-elevate">
              <CardContent className="p-6 space-y-3">
                <div className="h-12 w-12 rounded-md bg-primary/10 flex items-center justify-center">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <h4 className="text-lg font-semibold text-foreground">
                  Role-Based Access
                </h4>
                <p className="text-sm text-muted-foreground">
                  Six distinct roles: Superadmin, Admin, Marketing, Analyst,
                  Reviewer, and Client with granular permissions
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="p-6 space-y-3">
                <div className="h-12 w-12 rounded-md bg-chart-2/10 flex items-center justify-center">
                  <FileSearch className="h-6 w-6 text-chart-2" />
                </div>
                <h4 className="text-lg font-semibold text-foreground">
                  Vulnerability Database
                </h4>
                <p className="text-sm text-muted-foreground">
                  Preloaded vulnerability templates with CVSS scores, CWE
                  references, and remediation guidance
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="p-6 space-y-3">
                <div className="h-12 w-12 rounded-md bg-chart-3/10 flex items-center justify-center">
                  <Clock className="h-6 w-6 text-chart-3" />
                </div>
                <h4 className="text-lg font-semibold text-foreground">
                  Automated Workflows
                </h4>
                <p className="text-sm text-muted-foreground">
                  Track projects from client onboarding through testing, review,
                  delivery, and revalidation
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="p-6 space-y-3">
                <div className="h-12 w-12 rounded-md bg-chart-5/10 flex items-center justify-center">
                  <FileCheck className="h-6 w-6 text-chart-5" />
                </div>
                <h4 className="text-lg font-semibold text-foreground">
                  Review System
                </h4>
                <p className="text-sm text-muted-foreground">
                  Multi-stage review workflow with inline comments, correction
                  requests, and approval tracking
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="p-6 space-y-3">
                <div className="h-12 w-12 rounded-md bg-chart-1/10 flex items-center justify-center">
                  <BarChart3 className="h-6 w-6 text-chart-1" />
                </div>
                <h4 className="text-lg font-semibold text-foreground">
                  Analytics Dashboard
                </h4>
                <p className="text-sm text-muted-foreground">
                  Real-time insights into project status, vulnerability trends,
                  and team performance metrics
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="p-6 space-y-3">
                <div className="h-12 w-12 rounded-md bg-destructive/10 flex items-center justify-center">
                  <Lock className="h-6 w-6 text-destructive" />
                </div>
                <h4 className="text-lg font-semibold text-foreground">
                  Secure & Audited
                </h4>
                <p className="text-sm text-muted-foreground">
                  Complete audit trail, encrypted data storage, and secure file
                  upload with role-based data isolation
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        <section className="container mx-auto px-6 py-16">
          <div className="bg-card border border-border rounded-lg p-12 text-center">
            <h3 className="text-3xl font-bold text-foreground mb-4">
              Ready to streamline your security assessments?
            </h3>
            <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
              Join security teams who trust our platform for comprehensive VAPT
              lifecycle management
            </p>
            <Button size="lg" asChild data-testid="button-signin-bottom">
              <a href="/api/login">
                <CheckCircle className="h-5 w-5 mr-2" />
                Sign In to Get Started
              </a>
            </Button>
          </div>
        </section>
      </main>

      <footer className="border-t border-border bg-card/30 mt-16">
        <div className="container mx-auto px-6 py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Shield className="h-4 w-4" />
              VAPT Platform
            </div>
            <p className="text-sm text-muted-foreground">
              © 2025 VAPT Platform. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
