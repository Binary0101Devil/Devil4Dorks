import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, Database, Plus } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Vulnerability } from "@shared/schema";
import { SeverityBadge } from "@/components/SeverityBadge";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useState } from "react";

export default function Vulnerabilities() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [severityFilter, setSeverityFilter] = useState<string>("all");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");

  const { data: vulnerabilities, isLoading } = useQuery<Vulnerability[]>({
    queryKey: ["/api/vulnerabilities"],
    enabled: !!user,
  });

  if (!user) return null;

  const filteredVulnerabilities = vulnerabilities?.filter((vuln) => {
    const matchesSearch =
      !searchQuery ||
      vuln.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      vuln.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      vuln.cweId?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesSeverity =
      severityFilter === "all" || vuln.severity === severityFilter;

    const matchesCategory =
      categoryFilter === "all" || vuln.category === categoryFilter;

    return matchesSearch && matchesSeverity && matchesCategory;
  });

  const categories = Array.from(
    new Set(vulnerabilities?.map((v) => v.category).filter(Boolean))
  );

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground tracking-tight">
            Vulnerability Database
          </h1>
          <p className="text-muted-foreground mt-1">
            Browse and manage vulnerability templates
          </p>
        </div>
        {(user.role === "admin" || user.role === "superadmin") && (
          <Button data-testid="button-add-vulnerability">
            <Plus className="h-4 w-4 mr-2" />
            Add Vulnerability
          </Button>
        )}
      </div>

      <Card>
        <CardHeader className="border-b border-border">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search vulnerabilities..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search-vulnerabilities"
              />
            </div>
            <div className="flex gap-2">
              <Select value={severityFilter} onValueChange={setSeverityFilter}>
                <SelectTrigger className="w-[150px]" data-testid="select-severity-filter">
                  <SelectValue placeholder="Severity" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Severities</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="info">Info</SelectItem>
                </SelectContent>
              </Select>

              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-[180px]" data-testid="select-category-filter">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat || ""}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-32" />
              ))}
            </div>
          ) : filteredVulnerabilities && filteredVulnerabilities.length > 0 ? (
            <div className="divide-y divide-border">
              {filteredVulnerabilities.map((vuln) => (
                <div
                  key={vuln.id}
                  className="p-6 hover-elevate cursor-pointer"
                  data-testid={`vuln-row-${vuln.id}`}
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-lg text-foreground mb-2">
                          {vuln.title}
                        </h3>
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {vuln.description}
                        </p>
                      </div>
                      <SeverityBadge severity={vuln.severity} />
                    </div>

                    <div className="flex flex-wrap items-center gap-3">
                      {vuln.cvssScore && (
                        <Badge variant="outline" className="gap-1">
                          <span className="text-xs text-muted-foreground">
                            CVSS:
                          </span>
                          <span className="font-semibold">{vuln.cvssScore}</span>
                        </Badge>
                      )}

                      {vuln.cweId && (
                        <Badge variant="outline" className="gap-1">
                          <span className="text-xs text-muted-foreground">
                            CWE:
                          </span>
                          <span className="font-mono text-xs">
                            {vuln.cweId}
                          </span>
                        </Badge>
                      )}

                      {vuln.category && (
                        <Badge variant="secondary" className="text-xs">
                          {vuln.category}
                        </Badge>
                      )}

                      {vuln.isTemplate && (
                        <Badge
                          variant="outline"
                          className="text-xs border-primary/30 text-primary"
                        >
                          Template
                        </Badge>
                      )}
                    </div>

                    <div className="grid md:grid-cols-2 gap-4 pt-2">
                      <div className="space-y-1">
                        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                          Impact
                        </p>
                        <p className="text-sm text-foreground line-clamp-2">
                          {vuln.impact}
                        </p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                          Remediation
                        </p>
                        <p className="text-sm text-foreground line-clamp-2">
                          {vuln.remediation}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-12 text-center">
              <Database className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">
                No vulnerabilities found
              </h3>
              <p className="text-muted-foreground">
                {searchQuery || severityFilter !== "all" || categoryFilter !== "all"
                  ? "Try adjusting your filters"
                  : "The vulnerability database is empty"}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
