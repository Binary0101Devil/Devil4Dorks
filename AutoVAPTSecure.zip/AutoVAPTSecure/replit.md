# VAPT Report Management Platform

## Overview

A comprehensive web-based platform for managing Vulnerability Assessment and Penetration Testing (VAPT) and Configuration Review projects. The system orchestrates the complete lifecycle from client onboarding through testing, review, report delivery, and revalidation. It supports six distinct user roles (Superadmin, Admin, Marketing, Analyst, Reviewer, Client) with tailored workflows and permissions for each.

The platform automates report generation, manages a centralized vulnerability database, facilitates real-time collaboration, and tracks the complete assessment lifecycle including proof-of-concept documentation, remediation tracking, and revalidation workflows.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18 with TypeScript, bundled via Vite

**UI Component System**: Shadcn/ui (New York style) built on Radix UI primitives with custom theming
- Design philosophy: Carbon Design + Material Design hybrid for enterprise cybersecurity applications
- Emphasizes data clarity, professional trust signals, and complex workflow visualization
- Dark mode primary with comprehensive light mode support
- Severity-based color coding for vulnerability classifications (Critical, High, Medium, Low, Info)

**State Management**: 
- TanStack Query (React Query) for server state and data fetching
- React Hook Form with Zod validation for form state
- Local component state for UI interactions

**Routing**: Wouter (lightweight client-side routing)

**Styling**: 
- Tailwind CSS with custom design tokens
- CSS variables for theme switching
- HSL color system for consistent theming across modes
- Custom utility classes for elevation/interaction states

**Key Features**:
- Role-based navigation and UI rendering
- Real-time messaging and notifications (WebSocket architecture planned)
- Responsive design with mobile considerations
- Comprehensive status tracking with visual badges (projects, findings, vulnerabilities)

### Backend Architecture

**Runtime**: Node.js with Express.js

**API Design**: RESTful API with role-based access control middleware
- Authentication middleware validates user sessions before route access
- Role-checking middleware enforces permission boundaries
- Audit logging middleware tracks all significant actions

**Session Management**: 
- Express-session with PostgreSQL session store (connect-pg-simple)
- 7-day session TTL with secure, HTTP-only cookies

**Authentication**: Replit's OpenID Connect (OIDC) integration
- Uses openid-client with Passport.js strategy
- Automatic user creation/update on authentication
- Token refresh mechanism for long-lived sessions

**WebSocket Support**: 
- WebSocket server (ws library) for real-time features
- Designed for chat messages and live notifications
- Runs alongside Express HTTP server

**Key Design Patterns**:
- Storage abstraction layer (IStorage interface) separates data operations from route logic
- Middleware pipeline for cross-cutting concerns (auth, audit, error handling)
- Centralized error handling with consistent API responses

### Data Storage

**Database**: PostgreSQL (via Neon serverless driver)

**ORM**: Drizzle ORM with type-safe schema definitions

**Schema Design**:

**Core Entities**:
- `users`: Role-based user accounts (superadmin, admin, marketing, analyst, reviewer, client) with organization affiliation
- `projects`: VAPT assessment projects with status tracking, client associations, assigned analysts/reviewers
- `vulnerabilities`: Template library of security vulnerabilities (SQL injection, XSS, IDOR, etc.) with CVSS scores, CWE mappings, severity levels
- `findings`: Project-specific vulnerability instances with POC evidence, reproduction steps, impact analysis, remediation guidance
- `comments`: Review feedback and collaboration on findings
- `chat_messages`: Real-time team communication per project
- `notifications`: User-specific alerts for workflow events (assignments, reviews, client actions)
- `audit_logs`: Comprehensive activity tracking for compliance and security
- `sessions`: Secure session persistence

**Relationships**:
- Projects link to clients, analysts, reviewers (many-to-one with users)
- Findings reference both projects and vulnerability templates
- Comments and chat messages associate with projects and users
- Notifications target specific users and reference entities

**Status Workflows**:
- Projects: draft → assigned → in_progress → under_review → approved → sent_to_client → revalidation → completed
- Findings: open → acknowledged → fixed → revalidation_needed → verified_fixed/not_fixed

**Data Integrity**:
- TypeScript types generated from Drizzle schema ensure type safety across stack
- Zod schemas (via drizzle-zod) validate data at API boundaries
- Database constraints enforce referential integrity

### Authentication & Authorization

**Authentication Method**: Replit OIDC (production-ready OAuth 2.0 flow)

**User Provisioning**: 
- First-time users auto-created in database with default "client" role
- Profile information synced from OIDC claims (email, name, profile image)
- Superadmins can modify user roles and activation status

**Authorization Model**: Role-Based Access Control (RBAC)

**Permission Hierarchy**:
- **Superadmin**: Full system access including user management
- **Admin**: Project lifecycle management, team assignments, progress monitoring
- **Marketing**: Client onboarding, project creation, scope definition
- **Analyst**: Testing execution, finding documentation, revalidation
- **Reviewer**: Report review, feedback provision, approval/rejection
- **Client**: View findings, mark remediation status, upload evidence, request revalidation

**Implementation**:
- `requireRole` middleware enforces minimum role requirements per route
- Frontend conditionally renders UI elements based on user role
- Database queries filter results by user permissions

### External Dependencies

**Core Infrastructure**:
- **Neon Database**: Serverless PostgreSQL hosting with WebSocket support for real-time queries
- **Replit**: Platform hosting with built-in OIDC authentication

**Development Tools**:
- **Vite Plugins**: Runtime error overlay, cartographer (dependency visualization), dev banner
- **Drizzle Kit**: Database migrations and schema management

**Frontend Libraries**:
- **Radix UI**: 25+ headless UI components for accessibility and customization
- **date-fns**: Date manipulation and formatting
- **cmdk**: Command palette component
- **Lucide Icons**: Comprehensive icon library

**Backend Libraries**:
- **ws**: WebSocket server implementation
- **memoizee**: Function result caching for performance

**Type Safety & Validation**:
- **Zod**: Runtime type validation and schema definition
- **@hookform/resolvers**: React Hook Form integration with Zod

**Fonts**: 
- Google Fonts: Inter (UI text), JetBrains Mono (code/technical content)