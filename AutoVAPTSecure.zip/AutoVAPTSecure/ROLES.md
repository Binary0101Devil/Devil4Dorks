# User Roles and Permissions

This document outlines the different user roles available in the Security Assessment Platform and their respective permissions.

## Available Roles

### 1. **Super Admin** 👑
- **Email**: superadmin@securityassessment.com
- **User ID**: `00000000-0000-0000-0000-000000000001`
- **Permissions**:
  - Full system access
  - Manage all users and their roles
  - View, create, edit, and delete all projects
  - Manage vulnerability templates
  - Access all reports and findings
  - System configuration and settings
  - View audit logs

### 2. **Admin** 🛡️
- **Email**: admin@securityassessment.com
- **User ID**: `00000000-0000-0000-0000-000000000002`
- **Permissions**:
  - Manage users (except super admins)
  - View, create, edit, and delete projects
  - Assign projects to analysts and reviewers
  - View all findings and reports
  - Manage vulnerability templates
  - Access audit logs

### 3. **Marketing Team** 📊
- **Email**: marketing@securityassessment.com
- **User ID**: `00000000-0000-0000-0000-000000000003`
- **Permissions**:
  - Create new projects
  - Assign projects to analysts and reviewers
  - View all projects
  - View project status and reports
  - Cannot edit findings or perform assessments

### 4. **Analyst (Pen Tester)** 🔍
- **Email**: analyst@securityassessment.com
- **User ID**: `00000000-0000-0000-0000-000000000004`
- **Permissions**:
  - View assigned projects
  - Create and edit findings for assigned projects
  - Upload proof of concept (POC) and evidence
  - Add steps to reproduce vulnerabilities
  - Submit projects for review
  - View vulnerability templates
  - Cannot approve or publish reports

### 5. **Reviewer** ✅
- **Email**: reviewer@securityassessment.com
- **User ID**: `00000000-0000-0000-0000-000000000005`
- **Permissions**:
  - View assigned projects for review
  - Review findings submitted by analysts
  - Add comments and request changes
  - Approve findings
  - Request revalidation of fixes
  - Cannot create new findings
  - Cannot publish final reports to clients

### 6. **Client** 👤
- **Email**: client@company.com
- **User ID**: `00000000-0000-0000-0000-000000000006`
- **Organization**: Acme Corporation
- **Permissions**:
  - View own projects only
  - View approved findings and reports
  - View project status
  - Upload fix evidence
  - Communicate with analysts through project chat
  - Cannot access other clients' projects
  - Cannot create or edit findings

## Testing Different Roles

### Using the Role Switcher (Recommended)

1. **Log in** to the application using Replit Auth
2. Click the **Role Switcher** button in the top-right corner (Shield icon)
3. Select any role from the dropdown menu
4. The page will reload with your new role active
5. Test the features available to that role

### Role-Based Feature Access

| Feature | Super Admin | Admin | Marketing | Analyst | Reviewer | Client |
|---------|-------------|-------|-----------|---------|----------|--------|
| Create Projects | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| Assign Projects | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| View All Projects | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| Create Findings | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ |
| Edit Findings | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ |
| Review Findings | ✅ | ✅ | ❌ | ❌ | ✅ | ❌ |
| Approve Findings | ✅ | ✅ | ❌ | ❌ | ✅ | ❌ |
| View Reports | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Manage Users | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| Manage Vulnerabilities | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| View Audit Logs | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| Upload Fix Evidence | ✅ | ✅ | ❌ | ❌ | ❌ | ✅ |

## Workflow Example

### Typical Project Workflow:

1. **Marketing/Admin** creates a new project for a client
2. **Admin** assigns an **Analyst** and **Reviewer** to the project
3. **Analyst** performs security testing and creates findings
4. **Reviewer** reviews the findings and provides feedback
5. **Admin** approves and sends the report to the **Client**
6. **Client** views the report and uploads fix evidence
7. **Analyst** performs revalidation
8. **Reviewer** verifies the fixes
9. Project marked as completed

## Authentication Note

This application uses **Replit Auth** for authentication. When you log in:
- Your account is automatically created in the database
- By default, new users are assigned the "client" role
- Use the Role Switcher to test different roles
- The seeded users above are reference accounts that exist in the database

## Database Seeding

To re-seed the database with test users and vulnerability templates:

```bash
tsx server/seed.ts
```

This will create/update:
- 6 test user accounts (one for each role)
- 15 common vulnerability templates

## Security Considerations

⚠️ **Important**: The Role Switcher is intended for **development and testing only**. In a production environment:
- Remove or restrict the `/api/auth/switch-role` endpoint
- Implement proper role assignment through an admin panel
- Add additional authorization checks
- Log all role changes for audit purposes
