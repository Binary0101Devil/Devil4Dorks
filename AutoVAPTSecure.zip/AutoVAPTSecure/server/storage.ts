import {
  users,
  projects,
  vulnerabilities,
  findings,
  comments,
  chatMessages,
  notifications,
  auditLogs,
  type User,
  type UpsertUser,
  type Project,
  type InsertProject,
  type Vulnerability,
  type InsertVulnerability,
  type Finding,
  type InsertFinding,
  type Comment,
  type InsertComment,
  type ChatMessage,
  type InsertChatMessage,
  type Notification,
  type InsertNotification,
  type AuditLog,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, or, desc, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  getUsersByRole(role: string): Promise<User[]>;
  
  // Project operations
  getProjects(): Promise<Project[]>;
  getProjectById(id: string): Promise<Project | undefined>;
  getProjectsByClient(clientId: string): Promise<Project[]>;
  getProjectsByAnalyst(analystId: string): Promise<Project[]>;
  getProjectsByReviewer(reviewerId: string): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, project: Partial<InsertProject>): Promise<Project>;
  deleteProject(id: string): Promise<void>;
  
  // Vulnerability operations
  getVulnerabilities(): Promise<Vulnerability[]>;
  getVulnerabilityById(id: string): Promise<Vulnerability | undefined>;
  getVulnerabilitiesBySeverity(severity: string): Promise<Vulnerability[]>;
  createVulnerability(vuln: InsertVulnerability): Promise<Vulnerability>;
  
  // Finding operations
  getFindings(): Promise<Finding[]>;
  getFindingsByProject(projectId: string): Promise<Finding[]>;
  getFindingById(id: string): Promise<Finding | undefined>;
  createFinding(finding: InsertFinding): Promise<Finding>;
  updateFinding(id: string, finding: Partial<InsertFinding>): Promise<Finding>;
  deleteFinding(id: string): Promise<void>;
  
  // Comment operations
  getCommentsByProject(projectId: string): Promise<Comment[]>;
  getCommentsByFinding(findingId: string): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  deleteComment(id: string): Promise<void>;
  
  // Chat operations
  getChatMessagesByProject(projectId: string): Promise<ChatMessage[]>;
  getDirectMessages(userId1: string, userId2: string): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  
  // Notification operations
  getNotificationsByUser(userId: string): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationRead(id: string): Promise<void>;
  markAllNotificationsRead(userId: string): Promise<void>;
  
  // Audit log operations
  createAuditLog(log: {
    userId: string;
    action: string;
    entityType: string;
    entityId?: string;
    details?: any;
    ipAddress?: string;
  }): Promise<AuditLog>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(users.createdAt);
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, role as any));
  }

  // Project operations
  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects).orderBy(desc(projects.createdAt));
  }

  async getProjectById(id: string): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async getProjectsByClient(clientId: string): Promise<Project[]> {
    return await db
      .select()
      .from(projects)
      .where(eq(projects.clientId, clientId))
      .orderBy(desc(projects.createdAt));
  }

  async getProjectsByAnalyst(analystId: string): Promise<Project[]> {
    return await db
      .select()
      .from(projects)
      .where(eq(projects.assignedAnalystId, analystId))
      .orderBy(desc(projects.createdAt));
  }

  async getProjectsByReviewer(reviewerId: string): Promise<Project[]> {
    return await db
      .select()
      .from(projects)
      .where(eq(projects.assignedReviewerId, reviewerId))
      .orderBy(desc(projects.createdAt));
  }

  async createProject(project: InsertProject): Promise<Project> {
    const [newProject] = await db.insert(projects).values(project).returning();
    return newProject;
  }

  async updateProject(id: string, projectData: Partial<InsertProject>): Promise<Project> {
    const [updated] = await db
      .update(projects)
      .set({ ...projectData, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return updated;
  }

  async deleteProject(id: string): Promise<void> {
    await db.delete(projects).where(eq(projects.id, id));
  }

  // Vulnerability operations
  async getVulnerabilities(): Promise<Vulnerability[]> {
    return await db.select().from(vulnerabilities).orderBy(vulnerabilities.severity);
  }

  async getVulnerabilityById(id: string): Promise<Vulnerability | undefined> {
    const [vuln] = await db.select().from(vulnerabilities).where(eq(vulnerabilities.id, id));
    return vuln;
  }

  async getVulnerabilitiesBySeverity(severity: string): Promise<Vulnerability[]> {
    return await db
      .select()
      .from(vulnerabilities)
      .where(eq(vulnerabilities.severity, severity as any));
  }

  async createVulnerability(vuln: InsertVulnerability): Promise<Vulnerability> {
    const [newVuln] = await db.insert(vulnerabilities).values(vuln).returning();
    return newVuln;
  }

  // Finding operations
  async getFindings(): Promise<Finding[]> {
    return await db.select().from(findings).orderBy(desc(findings.createdAt));
  }

  async getFindingsByProject(projectId: string): Promise<Finding[]> {
    return await db
      .select()
      .from(findings)
      .where(eq(findings.projectId, projectId))
      .orderBy(findings.severity, desc(findings.createdAt));
  }

  async getFindingById(id: string): Promise<Finding | undefined> {
    const [finding] = await db.select().from(findings).where(eq(findings.id, id));
    return finding;
  }

  async createFinding(finding: InsertFinding): Promise<Finding> {
    const [newFinding] = await db.insert(findings).values(finding).returning();
    return newFinding;
  }

  async updateFinding(id: string, findingData: Partial<InsertFinding>): Promise<Finding> {
    const [updated] = await db
      .update(findings)
      .set({ ...findingData, updatedAt: new Date() })
      .where(eq(findings.id, id))
      .returning();
    return updated;
  }

  async deleteFinding(id: string): Promise<void> {
    await db.delete(findings).where(eq(findings.id, id));
  }

  // Comment operations
  async getCommentsByProject(projectId: string): Promise<Comment[]> {
    return await db
      .select()
      .from(comments)
      .where(eq(comments.projectId, projectId))
      .orderBy(comments.createdAt);
  }

  async getCommentsByFinding(findingId: string): Promise<Comment[]> {
    return await db
      .select()
      .from(comments)
      .where(eq(comments.findingId, findingId))
      .orderBy(comments.createdAt);
  }

  async createComment(comment: InsertComment): Promise<Comment> {
    const [newComment] = await db.insert(comments).values(comment).returning();
    return newComment;
  }

  async deleteComment(id: string): Promise<void> {
    await db.delete(comments).where(eq(comments.id, id));
  }

  // Chat operations
  async getChatMessagesByProject(projectId: string): Promise<ChatMessage[]> {
    return await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.projectId, projectId))
      .orderBy(chatMessages.createdAt);
  }

  async getDirectMessages(userId1: string, userId2: string): Promise<ChatMessage[]> {
    return await db
      .select()
      .from(chatMessages)
      .where(
        or(
          and(eq(chatMessages.senderId, userId1), eq(chatMessages.recipientId, userId2)),
          and(eq(chatMessages.senderId, userId2), eq(chatMessages.recipientId, userId1))
        )
      )
      .orderBy(chatMessages.createdAt);
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [newMessage] = await db.insert(chatMessages).values(message).returning();
    return newMessage;
  }

  // Notification operations
  async getNotificationsByUser(userId: string): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db.insert(notifications).values(notification).returning();
    return newNotification;
  }

  async markNotificationRead(id: string): Promise<void> {
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, id));
  }

  async markAllNotificationsRead(userId: string): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.userId, userId));
  }

  // Audit log operations
  async createAuditLog(log: {
    userId: string;
    action: string;
    entityType: string;
    entityId?: string;
    details?: any;
    ipAddress?: string;
  }): Promise<AuditLog> {
    const [auditLog] = await db.insert(auditLogs).values(log).returning();
    return auditLog;
  }
}

export const storage = new DatabaseStorage();
