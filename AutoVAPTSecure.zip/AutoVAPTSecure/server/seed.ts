import { db } from "./db";
import { users, vulnerabilities } from "@shared/schema";

const seedUsers = [
  {
    id: "00000000-0000-0000-0000-000000000001",
    email: "superadmin@securityassessment.com",
    firstName: "Super",
    lastName: "Admin",
    role: "superadmin" as const,
    organization: "Security Assessment Platform",
    isActive: true,
  },
  {
    id: "00000000-0000-0000-0000-000000000002",
    email: "admin@securityassessment.com",
    firstName: "Admin",
    lastName: "User",
    role: "admin" as const,
    organization: "Security Assessment Platform",
    isActive: true,
  },
  {
    id: "00000000-0000-0000-0000-000000000003",
    email: "marketing@securityassessment.com",
    firstName: "Marketing",
    lastName: "Manager",
    role: "marketing" as const,
    organization: "Security Assessment Platform",
    isActive: true,
  },
  {
    id: "00000000-0000-0000-0000-000000000004",
    email: "analyst@securityassessment.com",
    firstName: "Sarah",
    lastName: "Analyst",
    role: "analyst" as const,
    organization: "Security Assessment Platform",
    isActive: true,
  },
  {
    id: "00000000-0000-0000-0000-000000000005",
    email: "reviewer@securityassessment.com",
    firstName: "John",
    lastName: "Reviewer",
    role: "reviewer" as const,
    organization: "Security Assessment Platform",
    isActive: true,
  },
  {
    id: "00000000-0000-0000-0000-000000000006",
    email: "client@company.com",
    firstName: "Client",
    lastName: "User",
    role: "client" as const,
    organization: "Acme Corporation",
    isActive: true,
  },
];

const initialVulnerabilities = [
  {
    title: "SQL Injection",
    description: "The application is vulnerable to SQL injection attacks, allowing attackers to manipulate database queries and potentially access or modify sensitive data.",
    impact: "Attackers can bypass authentication, retrieve sensitive data, modify or delete database records, and potentially gain complete control over the database server.",
    remediation: "Use parameterized queries or prepared statements. Implement input validation and sanitization. Apply the principle of least privilege for database accounts. Use an ORM that handles SQL safely.",
    severity: "critical" as const,
    cvssScore: "9.8",
    cweId: "CWE-89",
    category: "Injection",
    isTemplate: true,
  },
  {
    title: "Cross-Site Scripting (XSS) - Reflected",
    description: "The application reflects user input without proper sanitization, allowing attackers to inject malicious scripts that execute in the victim's browser.",
    impact: "Attackers can steal session cookies, redirect users to malicious sites, deface web pages, or perform actions on behalf of the victim user.",
    remediation: "Implement proper output encoding based on context (HTML, JavaScript, URL). Use Content Security Policy (CSP) headers. Validate and sanitize all user inputs. Use modern frameworks with built-in XSS protection.",
    severity: "high" as const,
    cvssScore: "7.1",
    cweId: "CWE-79",
    category: "Injection",
    isTemplate: true,
  },
  {
    title: "Cross-Site Scripting (XSS) - Stored",
    description: "User-supplied data is stored on the server and later displayed to other users without proper sanitization, allowing persistent script execution.",
    impact: "Persistent attacks affecting all users who view the compromised content. Can lead to session hijacking, credential theft, or malware distribution.",
    remediation: "Sanitize all user input before storage. Encode output when rendering. Implement CSP. Use HTTPOnly and Secure flags on cookies. Validate input on both client and server side.",
    severity: "critical" as const,
    cvssScore: "8.8",
    cweId: "CWE-79",
    category: "Injection",
    isTemplate: true,
  },
  {
    title: "Insecure Direct Object Reference (IDOR)",
    description: "The application exposes direct references to internal objects (files, database records) without proper authorization checks, allowing unauthorized access.",
    impact: "Attackers can access, modify, or delete other users' data by manipulating object references. This can lead to data breaches and privacy violations.",
    remediation: "Implement proper access control checks for all object references. Use indirect reference maps. Validate user permissions before granting access to resources. Apply principle of least privilege.",
    severity: "high" as const,
    cvssScore: "7.5",
    cweId: "CWE-639",
    category: "Broken Access Control",
    isTemplate: true,
  },
  {
    title: "Broken Authentication",
    description: "Authentication mechanisms are implemented incorrectly, allowing attackers to compromise passwords, keys, session tokens, or exploit implementation flaws.",
    impact: "Attackers can assume identities of legitimate users, gain unauthorized access to accounts, and perform actions as the compromised user.",
    remediation: "Implement multi-factor authentication. Use strong password policies. Secure session management with proper timeout and invalidation. Use secure password storage (bcrypt, Argon2). Implement account lockout mechanisms.",
    severity: "critical" as const,
    cvssScore: "9.1",
    cweId: "CWE-287",
    category: "Authentication",
    isTemplate: true,
  },
  {
    title: "Sensitive Data Exposure",
    description: "The application does not adequately protect sensitive data such as financial information, health records, or personal identifiable information.",
    impact: "Exposure of sensitive data can lead to identity theft, financial fraud, privacy violations, and regulatory compliance failures.",
    remediation: "Encrypt sensitive data at rest and in transit using strong encryption algorithms. Implement proper key management. Apply data classification. Use HTTPS/TLS for all communications. Don't store sensitive data unnecessarily.",
    severity: "high" as const,
    cvssScore: "7.4",
    cweId: "CWE-311",
    category: "Cryptography",
    isTemplate: true,
  },
  {
    title: "XML External Entity (XXE) Injection",
    description: "The application parses XML input containing external entity references without proper validation, allowing file disclosure and server-side request forgery.",
    impact: "Attackers can access local files, scan internal networks, cause denial of service, or execute remote code in some cases.",
    remediation: "Disable XML external entity processing in all XML parsers. Use less complex data formats like JSON. Implement input validation. Update XML processors to patched versions. Use allow-lists for XML schemas.",
    severity: "high" as const,
    cvssScore: "8.2",
    cweId: "CWE-611",
    category: "Injection",
    isTemplate: true,
  },
  {
    title: "Broken Access Control",
    description: "Restrictions on authenticated users are not properly enforced, allowing users to access unauthorized functionality or data.",
    impact: "Users can view, modify, or delete content they shouldn't have access to. This can lead to data breaches, privilege escalation, and compliance violations.",
    remediation: "Implement deny-by-default access control. Enforce ownership checks on records. Disable directory listing. Log access control failures and alert admins. Use centralized access control mechanism.",
    severity: "high" as const,
    cvssScore: "8.1",
    cweId: "CWE-284",
    category: "Broken Access Control",
    isTemplate: true,
  },
  {
    title: "Security Misconfiguration",
    description: "The application, framework, or server is insecurely configured, often due to default settings, incomplete setups, or verbose error messages.",
    impact: "Attackers can exploit misconfigurations to gain unauthorized access, obtain sensitive information, or compromise the entire system.",
    remediation: "Implement secure configuration baseline. Remove unnecessary features and frameworks. Keep all components updated. Use security headers. Implement proper error handling without revealing system details. Conduct security reviews.",
    severity: "medium" as const,
    cvssScore: "6.5",
    cweId: "CWE-16",
    category: "Security Misconfiguration",
    isTemplate: true,
  },
  {
    title: "Cross-Site Request Forgery (CSRF)",
    description: "The application does not validate that requests are intentionally made by the authenticated user, allowing attackers to perform actions on behalf of victims.",
    impact: "Attackers can trick users into performing unintended actions such as changing account settings, making transactions, or modifying data.",
    remediation: "Implement anti-CSRF tokens for state-changing operations. Use SameSite cookie attribute. Verify Origin and Referer headers. Require re-authentication for sensitive actions. Use CAPTCHA for critical operations.",
    severity: "medium" as const,
    cvssScore: "6.5",
    cweId: "CWE-352",
    category: "Request Forgery",
    isTemplate: true,
  },
  {
    title: "Using Components with Known Vulnerabilities",
    description: "The application uses libraries, frameworks, or components with known security vulnerabilities that have not been patched.",
    impact: "Attackers can exploit known vulnerabilities to compromise the application, leading to data breaches, system compromise, or denial of service.",
    remediation: "Maintain an inventory of all components and versions. Monitor security bulletins for vulnerabilities. Remove unused dependencies. Only obtain components from official sources. Use automated tools to check for vulnerable dependencies.",
    severity: "high" as const,
    cvssScore: "7.3",
    cweId: "CWE-1035",
    category: "Vulnerable Components",
    isTemplate: true,
  },
  {
    title: "Insufficient Logging and Monitoring",
    description: "The application does not generate adequate logs or monitoring alerts, allowing attacks to go undetected for extended periods.",
    impact: "Attackers can operate undetected for longer periods, increasing the damage from breaches. Incident response and forensics are severely hampered.",
    remediation: "Log all authentication events, access control failures, and input validation failures. Ensure logs are tamper-proof. Implement real-time monitoring and alerting. Conduct regular log reviews. Establish incident response procedures.",
    severity: "low" as const,
    cvssScore: "3.7",
    cweId: "CWE-778",
    category: "Logging & Monitoring",
    isTemplate: true,
  },
  {
    title: "Server-Side Request Forgery (SSRF)",
    description: "The application fetches remote resources without validating user-supplied URLs, allowing attackers to make requests to internal systems.",
    impact: "Attackers can scan internal networks, access cloud metadata services, bypass firewalls, or interact with internal services not exposed to the internet.",
    remediation: "Validate and sanitize all user-supplied URLs. Use allow-lists for protocols and domains. Disable unused URL schemas. Implement network segmentation. Don't send raw responses to clients. Use separate DNS for external requests.",
    severity: "high" as const,
    cvssScore: "8.6",
    cweId: "CWE-918",
    category: "Server-Side Attacks",
    isTemplate: true,
  },
  {
    title: "Insecure Deserialization",
    description: "The application deserializes untrusted data without proper validation, potentially allowing remote code execution or other attacks.",
    impact: "Attackers can execute arbitrary code, perform injection attacks, escalate privileges, or cause denial of service.",
    remediation: "Avoid deserializing untrusted data. Implement integrity checks such as digital signatures. Isolate deserialization code with limited permissions. Log deserialization failures. Use simpler data interchange formats like JSON.",
    severity: "critical" as const,
    cvssScore: "9.0",
    cweId: "CWE-502",
    category: "Deserialization",
    isTemplate: true,
  },
  {
    title: "Missing or Weak Encryption",
    description: "Sensitive data is transmitted or stored without encryption, or using weak/outdated encryption algorithms.",
    impact: "Attackers can intercept and read sensitive data in transit or at rest, leading to data breaches and compliance violations.",
    remediation: "Use TLS 1.2+ for all data in transit. Encrypt sensitive data at rest using AES-256 or stronger. Use strong key management practices. Disable weak ciphers and protocols. Implement perfect forward secrecy.",
    severity: "high" as const,
    cvssScore: "7.5",
    cweId: "CWE-326",
    category: "Cryptography",
    isTemplate: true,
  },
];

async function seed() {
  try {
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    console.log("🌱 Starting Database Seed");
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");

    console.log("👥 Seeding Users...");
    for (const user of seedUsers) {
      await db
        .insert(users)
        .values(user)
        .onConflictDoUpdate({
          target: users.id,
          set: {
            ...user,
            updatedAt: new Date(),
          },
        });
      console.log(`  ✓ ${user.role.padEnd(13)} - ${user.email}`);
    }

    console.log("\n🔒 Seeding Vulnerability Templates...");
    for (const vuln of initialVulnerabilities) {
      await db.insert(vulnerabilities).values(vuln).onConflictDoNothing();
      console.log(`  ✓ ${vuln.title}`);
    }

    console.log("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    console.log("✅ Database Seeded Successfully!");
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");

    console.log("📝 Test User Accounts Created:");
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    console.log("Role          | Email                              | User ID");
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    seedUsers.forEach((user) => {
      console.log(`${user.role.padEnd(13)} | ${user.email.padEnd(34)} | ${user.id}`);
    });
    console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
    
    console.log(`📚 ${initialVulnerabilities.length} vulnerability templates loaded\n`);

    console.log("⚠️  Authentication Note:");
    console.log("   This app uses Replit Auth for authentication.");
    console.log("   When you log in with your Replit account, you will be");
    console.log("   automatically assigned a role based on your user ID.");
    console.log("   The seeded users above are for reference and testing.\n");

    process.exit(0);
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    process.exit(1);
  }
}

seed();
