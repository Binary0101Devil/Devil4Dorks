import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated, requireRole } from "./replitAuth";
import {
  insertProjectSchema,
  insertVulnerabilitySchema,
  insertFindingSchema,
  insertCommentSchema,
  insertChatMessageSchema,
  insertNotificationSchema,
  type Project,
} from "@shared/schema";

// Extend Express Request type
declare global {
  namespace Express {
    interface User {
      claims: {
        sub: string;
        email?: string;
        first_name?: string;
        last_name?: string;
        profile_image_url?: string;
      };
      access_token?: string;
      refresh_token?: string;
      expires_at?: number;
    }
    
    interface Request {
      dbUser?: any;
    }
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  await setupAuth(app);

  // Audit logging middleware
  const auditLog = async (req: Request, action: string, entityType: string, entityId?: string) => {
    if (req.dbUser) {
      await storage.createAuditLog({
        userId: req.dbUser.id,
        action,
        entityType,
        entityId,
        ipAddress: req.ip,
      });
    }
  };

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.post('/api/auth/switch-role', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { role } = req.body;
      const validRoles = ['superadmin', 'admin', 'marketing', 'analyst', 'reviewer', 'client'];
      
      if (!validRoles.includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }

      const userId = req.user!.claims.sub;
      await storage.upsertUser({
        id: userId,
        email: req.user!.claims.email,
        firstName: req.user!.claims.first_name,
        lastName: req.user!.claims.last_name,
        profileImageUrl: req.user!.claims.profile_image_url,
        role,
      });

      const updatedUser = await storage.getUser(userId);
      res.json(updatedUser);
    } catch (error: any) {
      console.error("Error switching role:", error);
      res.status(400).json({ message: error.message || "Failed to switch role" });
    }
  });

  // User routes
  app.get('/api/users', isAuthenticated, requireRole('admin', 'superadmin'), async (req: Request, res: Response) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get('/api/users/clients', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const clients = await storage.getUsersByRole('client');
      res.json(clients);
    } catch (error) {
      console.error("Error fetching clients:", error);
      res.status(500).json({ message: "Failed to fetch clients" });
    }
  });

  // Project routes
  app.get('/api/projects', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      let projects: Project[];
      
      switch (user.role) {
        case 'superadmin':
        case 'admin':
        case 'marketing':
          projects = await storage.getProjects();
          break;
        case 'analyst':
          projects = await storage.getProjectsByAnalyst(userId);
          break;
        case 'reviewer':
          projects = await storage.getProjectsByReviewer(userId);
          break;
        case 'client':
          projects = await storage.getProjectsByClient(userId);
          break;
        default:
          projects = [];
      }
      
      res.json(projects);
    } catch (error) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.get('/api/projects/:id', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const project = await storage.getProjectById(req.params.id);
      
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(project);
    } catch (error) {
      console.error("Error fetching project:", error);
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.post('/api/projects', isAuthenticated, requireRole('admin', 'superadmin', 'marketing'), async (req: Request, res: Response) => {
    try {
      const validatedData = insertProjectSchema.parse({
        ...req.body,
        createdById: req.dbUser.id,
      });
      
      const project = await storage.createProject(validatedData);
      await auditLog(req, 'create', 'project', project.id);
      
      // Create notification for assigned analyst
      if (project.assignedAnalystId) {
        await storage.createNotification({
          userId: project.assignedAnalystId,
          type: 'project_assigned',
          title: 'New Project Assigned',
          message: `You have been assigned to project: ${project.name}`,
          link: `/projects/${project.id}`,
        });
      }
      
      res.json(project);
    } catch (error: any) {
      console.error("Error creating project:", error);
      res.status(400).json({ message: error.message || "Failed to create project" });
    }
  });

  app.put('/api/projects/:id', isAuthenticated, requireRole('admin', 'superadmin'), async (req: Request, res: Response) => {
    try {
      const project = await storage.updateProject(req.params.id, req.body);
      await auditLog(req, 'update', 'project', project.id);
      res.json(project);
    } catch (error: any) {
      console.error("Error updating project:", error);
      res.status(400).json({ message: error.message || "Failed to update project" });
    }
  });

  app.delete('/api/projects/:id', isAuthenticated, requireRole('admin', 'superadmin'), async (req: Request, res: Response) => {
    try {
      await storage.deleteProject(req.params.id);
      await auditLog(req, 'delete', 'project', req.params.id);
      res.json({ message: "Project deleted successfully" });
    } catch (error) {
      console.error("Error deleting project:", error);
      res.status(500).json({ message: "Failed to delete project" });
    }
  });

  // Vulnerability routes
  app.get('/api/vulnerabilities', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const vulnerabilities = await storage.getVulnerabilities();
      res.json(vulnerabilities);
    } catch (error) {
      console.error("Error fetching vulnerabilities:", error);
      res.status(500).json({ message: "Failed to fetch vulnerabilities" });
    }
  });

  app.get('/api/vulnerabilities/:id', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const vulnerability = await storage.getVulnerabilityById(req.params.id);
      
      if (!vulnerability) {
        return res.status(404).json({ message: "Vulnerability not found" });
      }
      
      res.json(vulnerability);
    } catch (error) {
      console.error("Error fetching vulnerability:", error);
      res.status(500).json({ message: "Failed to fetch vulnerability" });
    }
  });

  app.post('/api/vulnerabilities', isAuthenticated, requireRole('admin', 'superadmin'), async (req: Request, res: Response) => {
    try {
      const validatedData = insertVulnerabilitySchema.parse(req.body);
      const vulnerability = await storage.createVulnerability(validatedData);
      await auditLog(req, 'create', 'vulnerability', vulnerability.id);
      res.json(vulnerability);
    } catch (error: any) {
      console.error("Error creating vulnerability:", error);
      res.status(400).json({ message: error.message || "Failed to create vulnerability" });
    }
  });

  // Finding routes
  app.get('/api/projects/:projectId/findings', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const findings = await storage.getFindingsByProject(req.params.projectId);
      res.json(findings);
    } catch (error) {
      console.error("Error fetching findings:", error);
      res.status(500).json({ message: "Failed to fetch findings" });
    }
  });

  app.post('/api/projects/:projectId/findings', isAuthenticated, requireRole('analyst', 'admin', 'superadmin'), async (req: Request, res: Response) => {
    try {
      const validatedData = insertFindingSchema.parse({
        ...req.body,
        projectId: req.params.projectId,
        createdById: req.dbUser.id,
      });
      
      const finding = await storage.createFinding(validatedData);
      await auditLog(req, 'create', 'finding', finding.id);
      res.json(finding);
    } catch (error: any) {
      console.error("Error creating finding:", error);
      res.status(400).json({ message: error.message || "Failed to create finding" });
    }
  });

  app.put('/api/findings/:id', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const finding = await storage.updateFinding(req.params.id, req.body);
      await auditLog(req, 'update', 'finding', finding.id);
      res.json(finding);
    } catch (error: any) {
      console.error("Error updating finding:", error);
      res.status(400).json({ message: error.message || "Failed to update finding" });
    }
  });

  app.delete('/api/findings/:id', isAuthenticated, requireRole('analyst', 'admin', 'superadmin'), async (req: Request, res: Response) => {
    try {
      await storage.deleteFinding(req.params.id);
      await auditLog(req, 'delete', 'finding', req.params.id);
      res.json({ message: "Finding deleted successfully" });
    } catch (error) {
      console.error("Error deleting finding:", error);
      res.status(500).json({ message: "Failed to delete finding" });
    }
  });

  // Comment routes
  app.get('/api/projects/:projectId/comments', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const comments = await storage.getCommentsByProject(req.params.projectId);
      res.json(comments);
    } catch (error) {
      console.error("Error fetching comments:", error);
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  app.post('/api/comments', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const validatedData = insertCommentSchema.parse({
        ...req.body,
        userId: req.dbUser.id,
      });
      
      const comment = await storage.createComment(validatedData);
      await auditLog(req, 'create', 'comment', comment.id);
      res.json(comment);
    } catch (error: any) {
      console.error("Error creating comment:", error);
      res.status(400).json({ message: error.message || "Failed to create comment" });
    }
  });

  // Notification routes
  app.get('/api/notifications', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.claims.sub;
      const notifications = await storage.getNotificationsByUser(userId);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.post('/api/notifications/:id/read', isAuthenticated, async (req: Request, res: Response) => {
    try {
      await storage.markNotificationRead(req.params.id);
      res.json({ message: "Notification marked as read" });
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  app.post('/api/notifications/read-all', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const userId = req.user!.claims.sub;
      await storage.markAllNotificationsRead(userId);
      res.json({ message: "All notifications marked as read" });
    } catch (error) {
      console.error("Error marking all notifications as read:", error);
      res.status(500).json({ message: "Failed to mark all notifications as read" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  // Setup WebSocket server for real-time chat and notifications
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  const clients = new Map<string, WebSocket>();

  wss.on('connection', (ws: WebSocket) => {
    let userId: string | null = null;

    ws.on('message', (message: string) => {
      try {
        const data = JSON.parse(message.toString());

        if (data.type === 'auth') {
          userId = data.userId;
          if (userId) {
            clients.set(userId, ws);
          }
        } else if (data.type === 'chat' && userId) {
          // Broadcast chat message to relevant users
          const { recipientId, content, projectId } = data;
          
          if (recipientId && clients.has(recipientId)) {
            const recipientWs = clients.get(recipientId);
            if (recipientWs && recipientWs.readyState === WebSocket.OPEN) {
              recipientWs.send(JSON.stringify({
                type: 'chat',
                senderId: userId,
                content,
                projectId,
                timestamp: new Date().toISOString(),
              }));
            }
          }
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      if (userId) {
        clients.delete(userId);
      }
    });
  });

  return httpServer;
}
